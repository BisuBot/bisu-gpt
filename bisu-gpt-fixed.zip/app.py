
import streamlit as st
import requests
import os

st.title("BisuGPT using OpenRouter")
st.write("Ask BisuGPT anything:")

user_input = st.text_input("")

api_key = os.getenv("OPENROUTER_API_KEY")  # Set this in Streamlit secrets or env
model = "openrouter/openai/gpt-3.5-turbo"

if user_input:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "HTTP-Referer": "https://bisu-gpt.streamlit.app",  # your actual Streamlit app URL
        "Content-Type": "application/json"
    }

    payload = {
        "model": model,
        "messages": [
            {"role": "user", "content": user_input}
        ]
    }

    try:
        response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload)
        response.raise_for_status()
        reply = response.json()["choices"][0]["message"]["content"]
        st.success(reply)
    except Exception as e:
        st.error(f"Something went wrong: {e}")
