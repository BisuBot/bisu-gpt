import streamlit as st
import openai

# Set the OpenRouter API endpoint
openai.api_base = "https://openrouter.ai/api/v1"
openai.api_key = st.secrets["OPENROUTER_API_KEY"]

# Set the model
model = "openrouter/openai/gpt-3.5-turbo"

st.title("BisuGPT")
user_input = st.text_input("Ask something to BisuGPT")

if user_input:
    with st.spinner("Thinking..."):
        response = openai.ChatCompletion.create(
            model=model,
            messages=[{"role": "user", "content": user_input}],
        )
        st.write(response['choices'][0]['message']['content'])
